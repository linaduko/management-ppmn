<?php  echo 123; phpinfo(); ?>
